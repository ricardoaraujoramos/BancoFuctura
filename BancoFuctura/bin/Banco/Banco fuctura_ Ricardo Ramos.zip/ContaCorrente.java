package Banco;

public class ContaCorrente extends Contas {

	public ContaCorrente(String nomeDoTitular, int numeroDaConta, double inicialdeposito) {
		super(nomeDoTitular, numeroDaConta, inicialdeposito);

	}

	public ContaCorrente(String nomeDoTitular, int numeroDaConta) {
		super(nomeDoTitular, numeroDaConta);

	}

}
