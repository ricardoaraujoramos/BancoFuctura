package Banco;

public class ContaPoupanca extends Contas {

	public ContaPoupanca(String nomeDoTitular, int numeroDaConta) {
		super(nomeDoTitular, numeroDaConta);

	}

}
